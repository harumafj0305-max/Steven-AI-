plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "jp.example.stevenassistant"
    compileSdk = 35

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "jp.example.stevenassistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.4"
        val backendUrl = System.getenv("STEVEN_BACKEND_URL") ?: "https://YOUR-SERVER.example/chat"
        val backendToken = System.getenv("STEVEN_BACKEND_TOKEN") ?: "SET_TOKEN_AT_BUILD"
        buildConfigField("String", "BACKEND_URL", "\"$backendUrl\"")
        buildConfigField("String", "BACKEND_TOKEN", "\"$backendToken\"")
    }
}
