package jp.example.stevenassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Prototype only: uses Android speech recognition in repeated short sessions.
 * This is NOT a robust offline wake-word engine. Recognition can stop, use network,
 * consume battery, or be throttled by the OS. A dedicated keyword model is preferable
 * for a production always-on assistant.
 */
class WakeWordService : Service() {
    companion object {
        const val ACTION_START = "jp.example.stevenassistant.START_WAKE"
        const val ACTION_STOP = "jp.example.stevenassistant.STOP_WAKE"
        private const val CHANNEL_ID = "steven_wake_channel"
        private const val NOTIFICATION_ID = 4301
        private const val TAG = "StevenWakeService"
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var running = false
    private var restarting = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopListening()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START, null -> {
                createNotificationChannel()
                startForeground(NOTIFICATION_ID, buildNotification("「ヘイ、スティーブン」を待機中"))
                if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                    updateNotification("この端末で音声認識を利用できません")
                    stopSelf()
                    return START_NOT_STICKY
                }
                running = true
                startRecognition()
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecognition() {
        if (!running || restarting) return
        restarting = true
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        restarting = false
                        updateNotification("「ヘイ、スティーブン」を待機中")
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) {
                        restarting = false
                        if (running) {
                            updateNotification("音声認識を再接続中…")
                            speechRecognizer?.destroy()
                            speechRecognizer = null
                            // No tight retry loop: Android speech service may throttle repeated requests.
                            android.os.Handler(mainLooper).postDelayed({ startRecognition() }, 1800)
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        restarting = false
                        val candidates = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val recognized = candidates?.firstOrNull().orEmpty()
                        Log.d(TAG, "Recognized text: $recognized")
                        processRecognition(recognized)
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val candidates = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val partial = candidates?.firstOrNull().orEmpty()
                        if (containsWakePhrase(partial)) {
                            // Partial results are only a hint; final results are handled below.
                            updateNotification("呼びかけを検出中…")
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ja-JP")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                startListening(intent)
            }
        } catch (e: Exception) {
            restarting = false
            Log.e(TAG, "Could not start recognition", e)
            updateNotification("音声認識を開始できません。アプリから停止・再開してください")
        }
    }

    private fun processRecognition(text: String) {
        if (!running) return
        val normalized = text.lowercase()
            .replace(" ", "")
            .replace("　", "")
            .replace("、", "")
            .replace("。", "")
            .replace(",", "")
        val variants = listOf("ヘイスティーブン", "heyスティーブン", "ヘイスティーブン")
        val index = variants.firstOrNull { normalized.contains(it) }
        if (index != null) {
            val query = text
                .replace(Regex("(?i)hey\\s*スティーブン"), "")
                .replace("ヘイ、スティーブン", "")
                .replace("ヘイスティーブン", "")
                .replace("ヘイ スティーブン", "")
                .trim(' ', '　', '、', ',', '。')
            notifyWake(query)
        } else {
            if (running) {
                restarting = false
                speechRecognizer?.destroy()
                speechRecognizer = null
                android.os.Handler(mainLooper).postDelayed({ startRecognition() }, 400)
            }
        }
    }

    private fun containsWakePhrase(text: String): Boolean {
        val normalized = text.lowercase().replace(" ", "").replace("　", "").replace("、", "")
        return normalized.contains("ヘイスティーブン") || normalized.contains("heyスティーブン")
    }

    private fun notifyWake(query: String) {
        updateNotification(if (query.isBlank()) "呼びかけを検出！通知をタップして会話" else "質問を検出！通知をタップして回答")
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_WAKE_QUERY, query)
        }
        val pending = PendingIntent.getActivity(
            this, 4302, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = buildNotification(
            if (query.isBlank()) "スティーブンが起きたよ。タップして会話しよう" else "質問を受け取ったよ。タップして回答を聞こう",
            pending
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, notification)
        // Pause listening while the user responds to avoid competing mic sessions.
        stopListening()
        running = false
    }

    private fun buildNotification(text: String, contentIntent: PendingIntent? = null): Notification {
        val stopIntent = Intent(this, WakeWordService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 4303, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        builder.setContentTitle("スティーブン")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "待機を停止", stopPending).build())
        if (contentIntent != null) builder.setContentIntent(contentIntent).setAutoCancel(true)
        return builder.build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "スティーブン音声待機", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "ウェイクワード待機中であることを表示します" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun stopListening() {
        running = false
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
        restarting = false
    }

    override fun onDestroy() {
        stopListening()
        super.onDestroy()
    }
}

