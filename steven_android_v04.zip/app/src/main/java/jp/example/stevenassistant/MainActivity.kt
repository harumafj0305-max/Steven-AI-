package jp.example.stevenassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONObject

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    companion object {
        private const val SPEECH_REQUEST = 1001
        private const val PERMISSION_REQUEST = 1002
        private const val PREFS_NAME = "steven_setup"
        private const val KEY_SETUP_COMPLETE = "setup_complete"
        private const val KEY_PASSWORD_HASH = "password_hash"
        const val EXTRA_WAKE_QUERY = "wake_query"
    }

    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var askButton: Button
    private lateinit var wakeButton: Button
    private lateinit var tts: TextToSpeech
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        if (prefs.getBoolean(KEY_SETUP_COMPLETE, false)) {
            showMainUi(intent)
        } else {
            buildSetupUi()
        }
    }

    private fun buildSetupUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        }
        val title = TextView(this).apply {
            text = "Steven AI 初期設定"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        val note = TextView(this).apply {
            text = "最初にアプリ用パスワードを設定してね。次回以降、この画面は表示されません。パスワードは忘れないように保管してください。"
            textSize = 15f
            setPadding(0, 18, 0, 18)
        }
        val password = EditText(this).apply {
            hint = "パスワード（6文字以上）"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }
        val confirm = EditText(this).apply {
            hint = "パスワードをもう一度入力"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }
        val save = Button(this).apply {
            text = "設定して開始"
            setOnClickListener {
                val first = password.text.toString()
                val second = confirm.text.toString()
                when {
                    first.length < 6 -> Toast.makeText(this@MainActivity, "6文字以上にしてね。", Toast.LENGTH_LONG).show()
                    first != second -> Toast.makeText(this@MainActivity, "パスワードが一致しないよ。", Toast.LENGTH_LONG).show()
                    else -> {
                        val hash = sha256(first)
                        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                            .putString(KEY_PASSWORD_HASH, hash)
                            .putBoolean(KEY_SETUP_COMPLETE, true)
                            .apply()
                        showMainUi(intent)
                    }
                }
            }
        }
        layout.addView(title)
        layout.addView(note)
        layout.addView(password, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(confirm, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(save)
        setContentView(layout)
    }

    private fun sha256(value: String): String {
        val bytes = java.security.MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun showMainUi(startIntent: Intent?) {
        if (!::tts.isInitialized) tts = TextToSpeech(this, this)
        buildUi()
        handleWakeIntent(startIntent)
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "スティーブン"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "準備OK。話しかけるか、待機を開始してね。"
            textSize = 16f
            setPadding(0, 20, 0, 20)
        }
        transcript = TextView(this).apply {
            text = "会話はここに表示されるよ。"
            textSize = 18f
            setPadding(0, 12, 0, 12)
        }
        val scroll = ScrollView(this).apply {
            addView(transcript)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        askButton = Button(this).apply {
            text = "🎙 スティーブンに話しかける"
            textSize = 18f
            setOnClickListener { startOneShotListening() }
        }
        wakeButton = Button(this).apply {
            text = "🔔 待機を開始"
            textSize = 16f
            setOnClickListener { requestPermissionsAndStartWakeService() }
        }
        val note = TextView(this).apply {
            text = "試作版：待機中はマイクを使用し、通知が表示されます。検出後は通知をタップして質問を送信します。"
            textSize = 12f
            setPadding(0, 16, 0, 0)
        }

        layout.addView(title)
        layout.addView(status)
        layout.addView(scroll)
        layout.addView(askButton)
        layout.addView(wakeButton)
        layout.addView(note)
        setContentView(layout)
    }

    private fun requestPermissionsAndStartWakeService() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), PERMISSION_REQUEST)
        } else {
            startWakeService()
        }
    }

    private fun startWakeService() {
        val intent = Intent(this, WakeWordService::class.java).apply {
            action = WakeWordService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        status.text = "待機を開始しました。通知から停止できます。"
        wakeButton.text = "待機中（停止は通知から）"
        wakeButton.isEnabled = false
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST) {
            val audioGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            if (audioGranted) startWakeService()
            else Toast.makeText(this, "待機にはマイク権限が必要です。", Toast.LENGTH_LONG).show()
        }
    }

    private fun startOneShotListening() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ja-JP")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "スティーブンに質問してね")
        }
        try {
            startActivityForResult(intent, SPEECH_REQUEST)
        } catch (_: Exception) {
            Toast.makeText(this, "音声認識を利用できません。端末の音声入力設定を確認してね。", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android, kept for broad compatibility in this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != SPEECH_REQUEST || resultCode != RESULT_OK) return
        val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            ?: return
        askSteven(spoken)
    }

    private fun handleWakeIntent(intent: Intent?) {
        val query = intent?.getStringExtra(EXTRA_WAKE_QUERY)?.trim().orEmpty()
        if (query.isNotBlank() && getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getBoolean(KEY_SETUP_COMPLETE, false)) {
            askSteven(query)
            intent?.removeExtra(EXTRA_WAKE_QUERY)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    private fun askSteven(message: String) {
        transcript.text = "あなた：$message\n\nスティーブン：考え中…"
        status.text = "AIに質問中…"
        askButton.isEnabled = false
        executor.execute {
            try {
                val backendUrl = BuildConfig.BACKEND_URL
                val backendToken = BuildConfig.BACKEND_TOKEN
                if (backendUrl.contains("YOUR-SERVER") || backendToken == "SET_TOKEN_AT_BUILD") {
                    throw IllegalStateException("バックエンドURLまたは認証トークンが未設定です。READMEの手順を確認してください。")
                }
                val conn = (URL(backendUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Authorization", "Bearer $backendToken")
                }
                conn.outputStream.use {
                    it.write(JSONObject().put("message", message).toString().toByteArray(Charsets.UTF_8))
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) throw IllegalStateException("サーバー応答エラー ($code)")
                val answer = JSONObject(response).optString("reply", "返事を読み取れなかったよ。")
                runOnUiThread {
                    transcript.text = "あなた：$message\n\nスティーブン：$answer"
                    status.text = "回答しました！"
                    askButton.isEnabled = true
                    if (answer.isNotBlank()) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "steven_reply")
                }
            } catch (e: Exception) {
                runOnUiThread {
                    transcript.text = "あなた：$message\n\nスティーブン：まだ接続できないよ。\n${e.message ?: "接続を確認してね。"}"
                    status.text = "接続設定を確認してください"
                    askButton.isEnabled = true
                }
            }
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale.JAPAN
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}

