import express from "express";
import { timingSafeEqual } from "node:crypto";

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "20kb" }));

const PORT = Number(process.env.PORT || 3000);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-6";
const APP_ACCESS_TOKEN = process.env.APP_ACCESS_TOKEN || "";
const ENABLE_WEB_SEARCH = process.env.ENABLE_WEB_SEARCH !== "false";
const WINDOW_MS = 15 * 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = Number(process.env.RATE_LIMIT_MAX || 30);
const MAX_DAILY_REQUESTS = Number(process.env.MAX_DAILY_REQUESTS || 200);
const requestWindows = new Map();
let dailyDate = new Date().toISOString().slice(0, 10);
let dailyCount = 0;

app.get("/", (_req, res) => {
  res.type("text").send("Steven AI backend is running.");
});

function validBearerToken(req) {
  if (APP_ACCESS_TOKEN.length < 32) return false;
  const header = req.get("authorization") || "";
  if (!header.startsWith("Bearer ")) return false;
  const supplied = Buffer.from(header.slice(7));
  const expected = Buffer.from(APP_ACCESS_TOKEN);
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}

function applyLimits(req, res) {
  const now = Date.now();
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  let window = requestWindows.get(ip);
  if (!window || now - window.startedAt >= WINDOW_MS) {
    window = { startedAt: now, count: 0 };
    requestWindows.set(ip, window);
  }
  if (window.count >= MAX_REQUESTS_PER_WINDOW) {
    res.set("Retry-After", String(Math.ceil((WINDOW_MS - (now - window.startedAt)) / 1000)));
    res.status(429).json({ error: "Too many requests. Try again later." });
    return false;
  }
  window.count += 1;

  const today = new Date().toISOString().slice(0, 10);
  if (today !== dailyDate) {
    dailyDate = today;
    dailyCount = 0;
  }
  if (dailyCount >= MAX_DAILY_REQUESTS) {
    res.status(429).json({ error: "Daily request limit reached." });
    return false;
  }
  dailyCount += 1;

  // Keep the in-memory map bounded; this is a prototype limit, not a durable quota.
  if (requestWindows.size > 5000) {
    for (const [key, value] of requestWindows) {
      if (now - value.startedAt >= WINDOW_MS) requestWindows.delete(key);
    }
  }
  return true;
}

app.post("/chat", async (req, res) => {
  if (!APP_ACCESS_TOKEN || APP_ACCESS_TOKEN.length < 32) {
    return res.status(503).json({ error: "Backend authentication is not configured." });
  }
  if (!validBearerToken(req)) {
    return res.status(401).json({ error: "Unauthorized." });
  }
  if (!applyLimits(req, res)) return;

  try {
    if (!OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI provider is not configured." });
    }

    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "message is required" });
    if (message.length > 8000) return res.status(413).json({ error: "message too long" });

    const tools = ENABLE_WEB_SEARCH ? [{ type: "web_search" }] : [];
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      signal: AbortSignal.timeout(45000),
      body: JSON.stringify({
        model: OPENAI_MODEL,
        instructions:
          "あなたの名前はスティーブン。日本語で親しみやすく正確に答える音声アシスタントです。" +
          "最新情報、現在の情報、調査が必要な質問には web_search ツールを使って確認してください。" +
          "検索結果を使った回答では、重要な出典URLを短い「参考リンク」欄として回答の末尾に含めてください。" +
          "確認できないことは断定せず、分からない場合はその旨を伝えてください。",
        tools,
        input: message
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("OpenAI API error status:", upstream.status);
      return res.status(502).json({ error: "AI provider request failed." });
    }

    const reply = typeof data.output_text === "string" ? data.output_text.trim() : "";
    if (!reply) return res.status(502).json({ error: "AI returned no text." });

    const sources = [];
    for (const item of (data.output || [])) {
      if (item.type !== "message") continue;
      for (const part of (item.content || [])) {
        for (const annotation of (part.annotations || [])) {
          if (annotation.type === "url_citation" && annotation.url && !sources.some(s => s.url === annotation.url)) {
            sources.push({ title: annotation.title || annotation.url, url: annotation.url });
          }
        }
      }
    }

    res.json({ reply, sources });
  } catch (error) {
    console.error("Chat request failed:", error?.name || "Error");
    res.status(500).json({ error: "Internal server error." });
  }
});

app.listen(PORT, () => console.log(`Steven backend listening on port ${PORT}`));
